#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
skill_audit/frontmatter_checker.py — Frontmatter 检查函数 (R-01~R-05, R-10)

[v2.36.0] 所有检查返回 filename:line 格式，方便直接定位。
"""

import re

def _find_fm_line(content, field_name=None):
    """
    返回 frontmatter 内的行号（1-indexed，相对于文件开头）。
    - 如果 field_name 非空：找到该字段所在行号。
    - 如果 field_name 为 None：返回 frontmatter 结束行号（第二个 --- 所在行），
      用于提示「应在哪一行之前插入缺失字段」。
    如果找不到 frontmatter，返回 1。
    """
    lines = content.split("\n")
    # 找第一个 ---
    fm_start = None
    for i, ln in enumerate(lines):
        if ln.strip() == "---":
            fm_start = i
            break
    if fm_start is None:
        return 1
    # 找第二个 ---
    fm_end = None
    for i in range(fm_start + 1, len(lines)):
        if lines[i].strip() == "---":
            fm_end = i
            break
    if fm_end is None:
        return fm_start + 2  # 保守估计

    if field_name is None:
        return fm_end + 1  # 1-indexed

    # 在 frontmatter 区间内搜索 field_name:
    pattern = re.compile(r'^' + re.escape(field_name) + r'\s*:')
    for i in range(fm_start + 1, fm_end):
        if pattern.match(lines[i]):
            return i + 1  # 1-indexed
    # 没找到字段：返回 fm_end（提示应插在 --- 前）
    return fm_end  # 1-indexed，即第二个 --- 所在行


def regex_frontmatter_exists(filepath, content, fm, body, **kw):
    """R-01: Frontmatter 存在性检查"""
    passed = fm is not None
    if not passed:
        # 找文件头行号（第 1 行）
        line = 1
        return {"passed": False,
                "detail": f"{filepath}:{line} - 缺少 YAML frontmatter（期望：文件以 --- 开头）",
                "fix": {"key": "frontmatter", "value": True,
                         "location": f"{filepath}:{line}",
                         "operation": "在文件头部插入 --- 包裹的 frontmatter 块，含 name/version/description/sensitive_access/critical_write/permission_weight",
                         "verification": "重新运行 audit_skill()，确认 R-01 passed"}}
    return {"passed": True,
            "detail": f"发现 YAML frontmatter"}


def yaml_has_name(filepath, content, fm, body, **kw):
    """R-02: name 字段检查"""
    has_name = fm is not None and "name" in fm
    line = _find_fm_line(content, "name") if has_name else _find_fm_line(content)
    if not has_name:
        return {"passed": False,
                "detail": f"{filepath}:{line} - 缺少 name 字段（期望：name: <技能名，与目录名一致>）",
                "fix": {"key": "name", "value": None,
                         "location": f"{filepath}:{line}",
                         "operation": f"添加 name: <技能名，与目录名一致>",
                         "verification": "重新运行 audit_skill()，确认 R-02 passed"}}
    return {"passed": True,
            "detail": f"{filepath}:{line} - name = {fm['name']}"}


def yaml_has_semver_version(filepath, content, fm, body, **kw):
    """R-03: version 字段 (SemVer) 检查"""
    has_ver = fm is not None and "version" in fm
    line = _find_fm_line(content, "version") if has_ver else _find_fm_line(content)
    if not has_ver:
        return {"passed": False,
                "detail": f"{filepath}:{line} - 缺少 version 字段（期望：SemVer x.y.z 格式）",
                "fix": {"key": "version", "value": "1.0.0",
                         "location": f"{filepath}:{line}",
                         "operation": "添加 version: 1.0.0 (必须符合 SemVer x.y.z 格式)",
                         "verification": "重新运行 audit_skill()，确认 R-03 passed"}}
    ver = str(fm["version"])
    semver_ok = bool(re.match(r'^\d+\.\d+\.\d+(-[a-zA-Z0-9.]+)?$', ver))
    if not semver_ok:
        return {"passed": False,
                "detail": f"{filepath}:{line} - version = {ver} ✗ 不符合 SemVer（期望：x.y.z）",
                "fix": {"key": "version", "value": "符合 SemVer 的值",
                         "location": f"{filepath}:{line}",
                         "operation": f"修改 version: {ver} → 符合 SemVer 格式 (x.y.z)",
                         "verification": "重新运行 audit_skill()，确认 R-03 passed"}}
    return {"passed": True,
            "detail": f"{filepath}:{line} - version = {ver} ✓"}


def yaml_has_description(filepath, content, fm, body, **kw):
    """R-04: description 字段检查"""
    has_desc = fm is not None and "description" in fm
    line = _find_fm_line(content, "description") if has_desc else _find_fm_line(content)
    if not has_desc:
        return {"passed": False,
                "detail": f"{filepath}:{line} - 缺少 description 字段（期望：≤120 字符的简要描述）",
                "fix": {"key": "description", "value": "<技能的简要描述>",
                         "location": f"{filepath}:{line}",
                         "operation": "添加 description: <技能的简要描述，一行概括技能用途>",
                         "verification": "重新运行 audit_skill()，确认 R-04 passed"}}
    dv = str(fm.get("description", ""))[:60]
    return {"passed": True,
            "detail": f'{filepath}:{line} - description = "{dv}"'}


def name_matches_dirname(filepath, content, fm, body, dirname=None, **kw):
    """R-05: name 与目录名一致检查"""
    if fm is None or "name" not in fm:
        return {"passed": False, "detail": "无法检查：无 frontmatter/name", "skip": True}
    if not dirname:
        return {"passed": True, "detail": "跳过：未提供目录名", "skip": True}
    line = _find_fm_line(content, "name")
    matched = fm["name"] == dirname
    if not matched:
        return {"passed": False,
                "detail": f"{filepath}:{line} - name({fm['name']}) != dirname({dirname})",
                "fix": {"key": "name", "value": dirname,
                         "location": f"{filepath}:{line}",
                         "operation": f"修改 name: {fm['name']} → {dirname} (与目录名一致)",
                         "verification": "重新运行 audit_skill()，确认 R-05 passed"}}
    return {"passed": True,
            "detail": f"{filepath}:{line} - name({fm['name']}) == dirname({dirname})"}


def version_matches_manifest(filepath, content, fm, body, manifest_version=None, **kw):
    """R-10: version 一致性检查（与 manifest 版本比对）"""
    if manifest_version is None:
        return {"passed": True, "detail": "跳过：未提供 manifest 版本号", "skip": True}
    if fm is None or "version" not in fm:
        return {"passed": False, "detail": "无 frontmatter/version，无法比对", "skip": True}
    line = _find_fm_line(content, "version")
    matched = str(fm["version"]) == str(manifest_version)
    if not matched:
        return {"passed": False,
                "detail": f"{filepath}:{line} - SKILL.md({fm['version']}) != manifest({manifest_version})",
                "fix": {"key": "version", "value": manifest_version,
                         "location": f"{filepath}:{line}",
                         "operation": f"修改 version: {fm['version']} → {manifest_version} (与 manifest.json 一致)",
                         "verification": "重新运行 audit_skill()，确认 R-10 passed"}}
    return {"passed": True,
            "detail": f"{filepath}:{line} - SKILL.md({fm['version']}) == manifest({manifest_version})"}
