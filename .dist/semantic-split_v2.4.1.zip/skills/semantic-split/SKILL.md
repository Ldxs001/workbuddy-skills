---
name: semantic-split
description: 语义拆分与智能规划技能。将自然语言拆分为结构化需求块，基于5W2H维度提取与约束标注增强语义理解，双视角推理整合为单一执行步骤，支持自增强json沉淀机制。
version: "2.4.1"
author: wUwproject
tags:
  - semantic-split
  - task-planning
  - json-accumulation
  - progressive-loading
  - 5w2h
  - constraint-annotation
---

# 语义拆分与智能规划技能 (Semantic Split v2.4)

## 核心能力

| # | 功能 | 说明 |
|---|------|------|
| 1 | **语义拆分** | 识别主语 → 划分块 → 提取目的/行为/动机 |
| 2 | **5W2H维度提取** | 自动抽取7维度 + 缺失维度填默认值（按任务类型映射表） |
| 3 | **约束强度标注** | 硬约束🔴/软约束🟡/无约束⚪ 三级标注 + 注意力锚定 |
| 4 | **双视角推理** | 聚焦（保守）+ 发散（创新）内部推理 → 整合为单一执行步骤 |
| 5 | **结构化输出** | 统一格式输出拆分结果（含约束标注），含确认询问 |
| 6 | **渐进式加载** | 规则级/能力级 json 渐进匹配，未命中时模型思考 |
| 7 | **自增强闭环** | 一次使用 → 沉淀 json → 下次复用 |
| 8 | **json 管理工具** | `json_manager.py` CLI 统一管理能力级/规则级 json |

---

## 快速开始

```bash
python scripts/json_manager.py scan --keywords 制作 PPT 产品    # 扫描匹配
python scripts/json_manager.py categorize --threshold 5        # 归类统计
python scripts/json_manager.py create --type capability --name my_task_v1  # 创建
python scripts/json_manager.py generalize --input <path> --params "具体值=[占位符]"  # 通用化
```

> 知识库 JSON 存放于 `~/.workbuddy/semantic-split/data/`（铁律4：产出物不嵌入技能目录）

---

## 第一部分：语义拆分规则（摘要）

> 详细规则见 `references/split_rules.md`

**核心流程**：识别主语 → 划分块 → 提取目的/行为/动机 → 5W2H维度 + 约束强度标注

| 主语类型 | 块标记 | 块内元素 |
|---------|--------|---------|
| 用户（"我"） | `块1：用户` | 目的 / 行为(诉求) / 动机 |
| AI助手（"你"） | `块2：执行者` | 同上 |
| 第三方 | `块3：第三方-N` | 同上 |

**边界情况速查**：

| 关键情况 | 处理 |
|---------|------|
| 约束强度冲突 | 按最高强度处理（🔴>🟡🔴>🟡>⚪） |
| 举例内容干扰 | 「比如/例如」后内容 → [EXAMPLE]，不作为核心约束 |
| json 库为空 | 跳过①②，直接进入③模型思考 |

---

## 第二部分：完整执行流程

### 步骤 1-2：接收输入 → 识别主语 & 划分块

接收用户原文 → 扫描识别主语代词（我/你/他/她/它/名称），每个独立主语 = 一个块

### 步骤 2.5：任务类型识别与 5W2H 初始化

> 内部执行，不输出。首次执行时读取 `references/task_type_defaults.md` + `references/constraint_annotation.md`

1. **任务类型识别**：制作PPT / 填写周报 / 安排行程 / 写邮件 / 策划活动 / 其他
2. **5W2H 维度初始化**：按任务类型从默认映射表填入默认值
3. **约束强度预标注**：🔴硬约束 / 🟡软约束 / ⚪无约束

### 步骤 3：提取块内元素（增强版）

**注意力锚定**（内部执行，不输出，详见 `references/constraint_annotation.md` 第三节）：
1. `[CRITICAL]` — 硬约束，后续不可违反
2. `[CORE]` — 核心目标（动词+宾语）
3. `[ENTITY]` — 数字、时间、人名
4. `[EXAMPLE]` — 举例内容，降权不作为约束
5. `[RESISTANCE]` — 「但是/担心/难」后内容
6. 核心句重构：「[主语] 要 [CORE] 于 [时间/场景]」（≤20字）

逐句提取目的/行为/动机 + 5W2H维度 + 约束强度（详见 `references/split_rules.md` 第五节）

### 步骤 4：结构化输出（增强版）

```
【拆分结果】

## 块 N：[主语名称]
  角色：[用户/执行者/第三方]
  目的：[核心目标]
  诉求：
    1. [核心交付物] 🔴  2. [支撑信息] 🟡  3. [附加要求] ⚪
  动机：[背景/原因/情绪]
  5W2H：Why/What/Who/Where/When/How/How much — [值] 🔴/🟡/⚪
  阻力：[描述]（如有）
  📌 核心句：[主语] 要 [CORE] 于 [时间/场景]

【确认询问】拆分是否完整准确？
```

### 步骤 4.5：自我反查（内部执行，不输出）

> 展示前强制执行（详见 `references/constraint_annotation.md` 第三节）：

| 反查 | 检查内容 | 修正 |
|------|---------|------|
| 1 | 硬约束遗漏：`[CRITICAL]` 是否全在结果中？ | 补充 |
| 2 | 约束误判：🟡 词被标为 🔴？ | 修正 |
| 2b | 隐式升级：🟡 约束属组织规范/法律/安全？→ 🟡🔴 或 🔴 | 升级 |
| 3 | 举例干扰：`[EXAMPLE]` 被当核心诉求？ | 降级 |
| 4 | 5W2H 缺失：有明显可推断维度？ | 补充 `[推断]` |

### 步骤 5：用户确认

- 如有遗漏 → 用户补充 → 更新结构
- 如全部正确 → 进入步骤 6

### 步骤 6：渐进加载与规划生成（增强版）

> 加载：`references/loading_decision_tree.md`（必须）+ `references/planning_rules.md` + `references/constraint_annotation.md` + `references/json_schema.md`（按需）

按决策树执行：
1. 扫描规则级 json → 命中则加载并展示
2. 不命中则扫描能力级 json → 命中则加载并展示
3. 均不命中则**模型思考**（需加载 `planning_rules.md`）
4. 展示规划 → 询问用户是否执行

**【模型思考：双视角推理→整合】**（详见 `references/planning_rules.md` 第六节，不输出双方案）

a) **聚焦方案**（内部）：5W2H取最窄值；守🔴硬约束；已验证方法；步骤≤30min
b) **发散方案**（内部）：5W2H取最宽值；🔴可轻微突破（标注风险）；引入非惯用工具
c) **整合**（输出）：聚焦为骨架 + 发散创新点→🌟增强步骤 → **单一执行步骤** + 工作包分解

展示给用户的规划格式（详细规则见 `references/planning_rules.md` 第六节）：

```
📌 任务：[名称] ｜🔴 硬约束：[列表] ｜🟡 软约束：[列表]

执行步骤：
  步骤 N: [名称] ── serial ── milestone: ✅/❌
    action: [操作] | depends_on: [依赖] | constraint_level: 🔴/🟡/⚪
  步骤 N🌟: [名称]（增强：来自发散方案）
    ⚠️ 风险：[说明]（如涉及🔴突破）

工作包：WP1: [描述](耗时, 前置) → 📍 检查点：[里程碑]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
来源：[规则级json / 能力级json / 模型思考（双视角整合）]
```

### 步骤 7：执行与 json 生成

- 用户确认执行 → 执行任务
- 分支③（不命中+确认执行）→ 完成后生成通用化能力级 json（加载 `json_schema.md`）
- 其他分支 → 不生成新 json（除非用户主动要求）

---

## 第三部分：触发条件

用户提出任务请求（"帮我做..."）、表达需求（"我需要..."）、委托工作（"交给你了..."）、描述问题寻求帮助时触发。简单问答和闲聊无需拆分。

---

## 脚本工具

`json_manager.py` — 管理能力级/规则级 json 的 CLI 工具（零外部依赖）

| 子命令 | 功能 |
|--------|------|
| `scan` / `categorize` | 按关键词扫描 / 按 tags 归类统计 |
| `create` / `validate` | 创建 json 骨架 / 验证格式 |
| `generalize` / `rule-gen` | 字段通用化 / 从能力级生成规则级 |
| `list` / `info` | 列出所有 json / 显示详情 |

---

## 参考文档（渐进加载）

| 文件 | 加载时机 |
|------|---------|
| `split_rules.md` | 步骤 2、3 首次 |
| `loading_decision_tree.md` | 步骤 6 **必须** |
| `planning_rules.md` | 模型思考时 |
| `json_schema.md` | 生成 json 时 |
| `constraint_annotation.md` | 步骤 2.5 / 3 / 6 |
| `task_type_defaults.md` | 步骤 2.5 首次 |
| `automation_tasks.md` | 定时任务时 |
| `examples.md` | 参考格式时 |

**v2.4.1** — 5W2H维度提取 · 约束强度标注(🔴🟡⚪) · 注意力锚定 · 双视角推理整合 · 工作包分解
